# InventoryManagementProject_Skill_India
In this project, a json file for record of grocery products and their attributes, a ipynb file for purchasing products and a ipynb file for the bill of purchased products has been created in Jupyter Notebook .
